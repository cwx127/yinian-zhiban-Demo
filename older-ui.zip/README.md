# 颐年智伴 Design System

面向银发群体的智能康养产品设计系统——以温暖、清晰、无障碍为核心，服务于日常健康提醒、家人关怀互动和紧急求助等场景。系统基于 `from-scratch` 路线构建，所有 token 值均来自品牌分析模型而非原始 Figma 提取。

## Source

- **Brand model:** `phase2-brand-analyst.json`（AI-generated brand inference）
- **Components:** 6 components (button, card, input, navigation, modal, tag)
- **Target platform:** 移动优先的康养类 App

## What this design system covers

- **Foundations** — 6 组色彩色阶 (teal / warm / success / warning / error / info) + 中性灰 + 表面色阶；双字体栈 Lora + Noto Sans SC；8 级间距；5 级阴影
- **Components** — 6 documented components: 按钮、卡片、输入框、导航栏、弹窗、标签
- **Dark theme** — 完整 `.dark` 语义映射，色阶反转而非简单取反

---

## CONTENT FUNDAMENTALS

### Voice & tone

品牌定位为"银发用户的智能伴侣"，语气应当亲切但不居高临下，简洁但不冷淡。文案使用简体中文，句式短、指令明确，避免抽象隐喻或网络用语。产品面向的典型用户对触控操作和阅读小字可能有困难，因此文案长度受到克制：标题通常不超过一行，正文段落控制在三句以内。界面上不使用 emoji，也不使用过于口语化的表达——"智能提醒"而非"贴心小闹钟"，"一键求助"而非"紧急SOS大按钮"。整体语言风格接近一位耐心、稳重的家庭护理人员。

### Concrete copy examples (from the UI kit plan)

- **首页仪表盘:** "智能提醒" — 功能卡片标题，传达主动式关怀而非被动通知
- **健康报告:** "健康日报" — 日报入口名称，简洁且日常化
- **家人关怀:** "家人关怀" — 社交互动模块标题，强调连接而非技术
- **紧急求助:** "一键求助" — 关键操作按钮文案，极简指令风格
- **天气模块:** "今日天气" — 信息卡片标题，日常口语化

### When generating copy

- 优先使用动词 + 名词结构（"健康日报"而非"每日健康数据报告"）
- 标题控制在 2-6 个汉字，正文每句不超过 20 字
- 避免使用英文术语或缩写（用"设置"而非"Settings"）
- 状态描述使用中性语气（"待处理"而非"警告！"）
- 所有功能入口使用直白的功能名称，不使用隐喻

---

## Visual Foundations

### Color

品牌以 **teal** (`#2e8b7b`) 作为主色——一种沉稳而温和的蓝绿色，在医疗健康领域传达信任感和安全感，同时避免了纯蓝的冷峻感。主色用于核心交互元素（按钮、导航高亮、链接）以及聚焦环。次级色为 **warm**（`#d4956a`），一种温暖的琥珀/陶土色，作为点缀和强调使用，传达关怀的温度。这两组色阶各包含 10 级（50-900），从近白到近黑，形成完整的视觉重量梯度。

语义色方面：success (`#3ba94f`) 取自然绿色系，warning (`#e8940a`) 为琥珀黄，error (`#dc3545`) 为标准警示红，info (`#2b7cc8`) 为冷静蓝色。每组同样为 10 级色阶，允许在 toast 提示、状态标签、表单校验等场景中灵活取用不同权重。所有语义色均提供 `*-50` 背景色用于 container 变体（如 `--error-container: #fef0f0`）。

中性色 (`--older-neutral`) 从 `#f7f5f3`（近白偏暖）到 `#2d2a26`（深棕黑），带有明显的暖色基底——这是刻意的选择，让整体界面远离冷灰的现代感，更像家居环境的自然色调。`--muted: #8b8580` 是最常用的辅助文字色，与暖白背景 (`--bg: #faf8f5`) 搭配保持 WCAG AA 对比度。

表面色阶 (`--surface` / `--surface-dim` / `--surface-container-low/high/highest`) 提供了 6 级容器深度，从 `#faf8f5` 到 `#e3dbd2`，用于卡片、导航栏、弹窗背景的层级区分。暗色模式下整体翻转为深棕色调 (`--surface: #1e1c1a`)，色阶从 `#252220` 到 `#433e39`，保持暖色基底。

### Typography

字体选择反映品牌的双面性：**Lora**（衬线体）用于 display 和 heading 层级，带来一种优雅、有温度的阅读体验——对于银发用户，衬线体在较大字号下能辅助字符辨识。Lora 作为 Google Fonts 的开源字体，涵盖 Latin 和基本 Cyrillic 字符集，通过 CDN 加载。

**Noto Sans SC**（思源黑体简体中文）用于 body 文本、caption、eyebrow 和 mono 文本。它是中文 UI 领域事实上的标准无衬线字体，笔画清晰、字号还原一致，非常适合需要跨设备一致性的场景。在 `--font-mono` 声明中同样使用 Noto Sans SC（实际渲染时浏览器会 fallback 到系统等宽字体，因为 Noto Sans SC 本身并非等宽字体）。

字号层级跨越较大范围：display 56px（3.5rem）用于首页大标题，h1 40px、h2 32px 逐级递减，body 18px 是全文正文的基准字号——比常见的 14-16px 更大，明确服务于可读性。caption 14px 用于标签和辅助信息，eyebrow 12px 用于分类标签和大写提示文字（带 `letter-spacing: 0.06em` 和 `text-transform: uppercase`）。

行高策略：display 和 h1-h2 使用紧凑行高（1.2-1.3），body 和 lead 使用宽松行高（1.75-1.8），配合大字号确保长文阅读舒适。字重方面，heading 统一使用 600（h1 为 700），body 使用 400，eyebrow 使用 600——高对比的字重组合帮助用户快速区分信息层级。

### Spacing

间距系统基于 4px 基准单位，提供 8 级 token：4px / 8px / 12px / 16px / 24px / 32px / 48px / 64px（`--space-1` 到 `--space-8`）。这不是严格的 4 倍递增——12px 和 24px 的存在反映了实际 UI 中频繁需要的"略大于半英寸"间距。组件内部间距普遍使用 `--space-3`（12px）和 `--space-4`（16px），卡片 padding 使用 `--space-6`（32px），弹窗内边距达到 `--space-8`（64px），为老年用户提供充足的视觉呼吸空间。

控件高度同样反映"大而清晰"的设计哲学：输入框 48px（`--size-input-height`），按钮三级 36px / 44px / 52px（sm / md / lg）。这些尺寸均超过 iOS HIG 和 Material Design 的最小触控目标（44px），lg 按钮更是达到 52px，为手部震颤用户提供了更大的命中区域。

### Radius

圆角值为 5 级，整体偏向温和但不过于圆润：`--radius-sm: 8px` 用于按钮小尺寸变体和标签内元素；`--radius-md: 10px` 用于标准按钮和卡片操作按钮；`--radius-lg: 12px` 用于输入框和 lg 按钮；`--radius-xl: 16px` 用于卡片和弹窗——这是容器的默认圆角，在视觉上形成"柔和的托盘"感；`--radius-full: 9999px` 仅用于标签（tag）和头像元素，形成胶囊形态。没有使用低于 8px 的圆角——这避免了视觉上的锐利感，符合品牌"温柔陪伴"的定位。

### Shadow / Elevation

阴影系统共 5 级，使用品牌中性色 `rgba(45,42,38,...)` 作为阴影色，而非纯黑。这确保了阴影在暖色调界面上的自然融入。

1. **shadow-1 (Card):** `0 1px 3px rgba(45,42,38,.06), 0 1px 2px rgba(45,42,38,.04)` — 极轻的抬起感，用于静态卡片
2. **shadow-2 (Card Hover):** `0 4px 8px rgba(45,42,38,.08), 0 2px 4px rgba(45,42,38,.04)` — 卡片悬停时的温和浮起
3. **shadow-3 (Float):** `0 8px 24px rgba(45,42,38,.10), 0 4px 8px rgba(45,42,38,.05)` — 浮动元素如 dropdown
4. **shadow-4 (Modal):** `0 16px 40px rgba(45,42,38,.14), 0 8px 16px rgba(45,42,38,.06)` — 弹窗层级的明确抬升
5. **shadow-5 (Overlay):** `0 24px 60px rgba(45,42,38,.18), 0 12px 24px rgba(45,42,38,.08)` — 全屏遮罩上的最高层级

阴影透明度递增极其克制（6% -> 8% -> 10% -> 14% -> 18%），整体效果是"若有若无的层次感"而非戏剧性的深度。暗色模式下阴影切换为纯黑色基础（`rgba(0,0,0,...)`），透明度同步提高（20% -> 36%）以补偿深色背景上的对比度损失。

### Borders

边框风格统一为 1-1.5px 细线，颜色使用 `--color-border` / `--color-outline`（`#e0dbd4` / `#383530` 暗色模式）。卡片默认使用 1px 实线边框，outlined 变体加粗到 1.5px；输入框统一使用 1.5px 边框，聚焦时过渡到 primary 色并附带 3px 的 primary 色外发光（`rgba(46,139,123,0.15)`）。导航栏通过底部 1px border 划分区域，active 状态通过 2px 底部 border 指示。整体边框哲学是"可见但不喧宾夺主"——引导视觉分区而非制造视觉噪音。

### Transitions

所有交互状态过渡统一使用 `0.15s` 时长，属性限制在 `background`、`border-color`、`opacity` 和 `filter`，不使用 `transform` 或复杂的 keyframe 动画。这种克制确保了即使在高刷新率设备上也不会出现令人不适的快速闪烁，同时也避免了过慢的过渡让用户怀疑操作是否生效。按钮 active 状态使用 `filter: brightness(0.95/0.97)` 而非颜色切换，产生微妙的"按压感"。

---

## Component Patterns

| Component | Preview | Contract | CSS Source | Key Facts | Key Insight |
|---|---|---|---|---|---|
| 按钮 | `preview/component-button.html` | `components/button.json` | `components.css` Button | 4 variants (primary/secondary/outline/ghost), 3 sizes (sm 36px / md 44px / lg 52px) | 大触控区域、圆角温和、ghost 状态用于辅助操作 |
| 卡片 | `preview/component-card.html` | `components/card.json` | `components.css` Card | 3 variants (default/elevated/outlined), 内含 title/desc/icon-row/body/action/list | 温暖容器、32px 内距留白充足、hover 用 brightness 而非 shadow |
| 输入框 | `preview/component-input.html` | `components/input.json` | `components.css` Input | 48px 高度, 1.5px border, focus ring 3px teal glow, error state | 大字号标签、宽触控友好、聚焦过渡温润不刺眼 |
| 导航栏 | `preview/component-navigation.html` | `components/navigation.json` | `components.css` Navigation | 2 variants (top-nav 64px / bottom-nav 72px), active 2px 底部指示器 | 清晰层级、底部导航适配移动端、logo 用 heading 字体 |
| 弹窗 | `preview/component-modal.html` | `components/modal.json` | `components.css` Modal | 2 variants (default/wide), 56px icon-area, 64px 内距 | 半透明遮罩温润、内容区圆角柔和、操作按钮醒目 |
| 标签 | `preview/component-tag.html` | `components/tag.json` | `components.css` Tag | 4 variants (default/success/warning/error), 2 sizes (default/sm), pill 形态 | 状态标签色彩温润、圆角胶囊形、字号偏大易读 |

---

## Index

- `README.md` — this file (brand narrative & visual foundations reference)
- `colors_and_type.css` — single combined CSS token file; link it in production, do not read for token understanding
- `components.css` — aggregated component CSS extracted from preview pages
- `css.json` — structured JSON token representation for programmatic consumption
- `preview/` — 6 component preview HTML cards (button, card, input, navigation, modal, tag)
- `components/` — per-component JSON contracts and index
- `uikit-plan.json` — screen blueprints and component whitelist

---

## Caveats / known substitutions

1. **Lora** is a Google Fonts web font loaded via CDN `@import`. For offline or air-gapped deployments, self-host the woff2 files or substitute **Georgia** / **Noto Serif** as a visual approximation. Lora lacks CJK glyph coverage — all Chinese text will fallback to Noto Sans SC regardless.

2. **Noto Sans SC** in the `--font-mono` slot is not a monospace font. The CSS declaration `font-family: 'Noto Sans SC', monospace` relies on the browser's `monospace` fallback for code/numeric alignment contexts. If precise monospace rendering is needed, consider adding **Source Code Pro** or **JetBrains Mono** to the stack.

3. All color scales and typography tokens are **AI-generated** (marked with `/* AI-generated */` in CSS). They were inferred from brand positioning analysis (`phase2-brand-analyst.json`) rather than extracted from an original Figma library. No source-of-truth Figma file exists for cross-validation.

4. The BrandFile (`phase2-brand-analyst.json`) was empty at read time, so all values in this document are derived exclusively from `colors_and_type.css` and `components.css`. Copy examples are drawn from `uikit-plan.json` screen blueprints, not from observed UI annotations.

5. Dark theme shadow values use generic `rgba(0,0,0,...)` rather than brand-neutral `rgba(45,42,38,...)`. This is a pragmatic simplification—on dark backgrounds the difference is imperceptible at the low opacity ranges used.

6. Component contracts are `from-scratch` with `schemaVersion: 1`. They represent inferred component intent, not observed Figma anatomy. The `keyInsightSeed` fields in `components/index.json` are generated summaries, not extracted from designer annotations.
